<h2>Hello {{ $email }}</h2>
<h2>Number: {{ $number }}</h2>
<h3>Message: {{$subject}}</h3>