<div class="aa-input-container careerfy-banner-search" id="aa-input-container">

    <input type="search" id="aa-search-input" class="aa-input-search" placeholder="Location For Job Search..." name="search" autocomplete="off" />
    <button type="submit"><i class="careerfy-icon careerfy-search"></i></button>                      
</div>